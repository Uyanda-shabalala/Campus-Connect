<?php
require __DIR__ . '/../../../vendor/autoload.php';

use Ratchet\Http\HttpServer;
use Ratchet\Server\IoServer;
use Ratchet\WebSocket\WsServer;
use App\WebSocket\ChatServer;




$chatserver = new ChatServer();//create a new instnce of the object chatserver 

$server = IoServer::factory(
    new HttpServer(
        new WsServer($chatserver)

    ),
    8080//server in which the websocket will run on 
);
echo "Server running on ws://localhost:8080\n";
$server->run();



?>