<?php
namespace App\WebSocket;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
require_once __DIR__ . "/../database.php";

class ChatServer implements MessageComponentInterface
{

    protected $clients;
    protected $userConnections = [];


    //create the constructor for the     

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        echo "Chat server started...\n";
    }

    //messaging methods 

    //when the user opens a chat 


    public function onopen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn);//attach a new connect to the chat server to the each client in the list of clients 
        //$this refers to the chatserver object 
        //$this->clients means in the chatserver class access the clients property of the class 


    }

    public function onMessage(ConnectionInterface $from, $msg)
    {//method for when a message is sent  it takes in who the message is from and the contents of the message

        try {
            $data = json_decode($msg, true);
            echo "Message from {$from->resourceId}: {$data['message']}\n";//resource id is a built in websocket "feature" that assigns a number to each connected user to the chat server 

            //display the message to all the clients(users both receiving and sending )
            foreach ($this->clients as $client) {

                //only send the message to the receiver and back to the sender
                if ($client === $from || (isset($data['receiver']) && $client->resourceId == $data['receiver'])) {
                    $client->send(json_encode(
                        [
                            'sender' => $data['sender'],
                            'receiver' => $data['receiver'],
                            'message' => $data['message']
                        ]
                    ));
                }
            }
            echo "Finished processing message and broadcasting.\n";
        } catch (\Exception $e) {
            echo "ERROR IN onMessage: " . $e->getMessage() . "\n";
            $from->close(); // Close the connection due to error
        }

    }


    public function onClose(ConnectionInterface $conn)
    {
        foreach ($this->userConnections as $userId => $connection) {
            if ($connection === $conn) {
                unset($this->userConnections[$userId]);
                echo "User $userId disconnected\n";
                break;
            }
        }
        $this->clients->detach($conn);
    }


    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        echo "Error: {$e->getMessage()}\n";
        $conn->close();
    }


}





?>