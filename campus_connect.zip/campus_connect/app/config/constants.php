<?php
// constants to be used throughout the application e.g. image paths

$profile_pics_path = __DIR__ . '/../../public/uploads/user_pp/';
$post_images_path = __DIR__ . '/../../public/uploads/post_images/';
$post_videos_path = __DIR__ . '/../../public/uploads/post_videos/';
//array storing all the universities, Personal note: i feel like there is a more efficient way of doing this 
$campuses = [
    "University of Johannesburg",
    "Rhodes University",
    "University of Cape Town",
    "University of South Africa",
    "Walter Sisulu University",
    "University of Pretoria",
    "University of Fort Hare",
    "University of KwaZulu-Natal",
    "University of Venda",
    "University of Limpopo",
    "North-West University",
    "Stellenbosch University",
    "Tshwane University of Technology",
    "Cape Peninsula University of Technology",
    "Durban University of Technology",
    "Varsity College",
    "Monash South Africa",
    "Mangosuthu University of Technology",
    "university of the Free State",
    "Central University of Technology",
    "University Of Witwatersrand",
    "Richfield Graduate Institute of Technology",
];


?>