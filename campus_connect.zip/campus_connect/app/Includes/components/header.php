<head>

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <header>
        <div class="container header-container">

            <h1>Campus Connect</h1>



            <nav>
                <ul>
                    <li><a href="../../public/pages/dashboard.php"><span class="material-symbols-outlined">
                                home
                            </span></a></li>

                    <li><a href="../../public/pages/profile.php"><span class="material-symbols-outlined">
                                person
                            </span></a></li>
                    <li><a href="../../public/pages/messages.php"><span class="material-symbols-outlined">
                                chat
                            </span></a></li>
                    <li>
                        <a href="../../public/pages/logout.php"><span class="material-symbols-outlined">
                                logout
                            </span></a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
</head>