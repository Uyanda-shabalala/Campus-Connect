<footer>
    <div class="container footer-container">
        <p>&copy; 2025 Campus Connect | All rights reserved</p>
    </div>
</footer>